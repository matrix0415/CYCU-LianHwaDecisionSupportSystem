ScanditSDKDemo and Scandit SDK 3.0+

ScanditSDKDemo is a (very) simple sample application written by the 
Scandit team which contains the Scandit SDK libraries. It was created to demonstrate the Scandit SDK project setup needed to use the Scandit SDK in a more complex project.

To get started, check out the information on http://www.scandit.com. The web page provides information on how to

* build and run the ScanditSDKDemo project
* use the ScanditSDK in your own project

 

